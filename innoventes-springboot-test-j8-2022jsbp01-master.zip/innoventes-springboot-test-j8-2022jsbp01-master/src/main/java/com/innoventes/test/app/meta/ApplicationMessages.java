package com.innoventes.test.app.meta;

public class ApplicationMessages {

	private ApplicationMessages() {
		super();
	}

	public static final String WELCOME_TEXT = "welcome.text";
}
